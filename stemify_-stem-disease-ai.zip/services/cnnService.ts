
import { CnnInference, CnnProbability } from "../types";
import { LABEL_MAPPING } from "../constants";

/**
 * STEMIFY NEURAL INFERENCE ENGINE (Simulation)
 * Mimics a ResNet50/MobileNetV2 pipeline in the browser.
 */
export const CnnService = {
  /**
   * Performs simulated CNN inference on the provided image.
   * Implements rejection logic for low-res/blank images and confidence thresholds.
   */
  runInference: async (base64: string): Promise<CnnInference> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = async () => {
        // 1. Safety Check: Resolution
        if (img.width < 128 || img.height < 128) {
          return resolve({
            predictedClass: "None",
            confidence: 0,
            top3: [],
            heatmap: base64,
            status: 'rejected',
            rejectionReason: "Image resolution too low for neural feature extraction (min 128x128).",
            architecture: "MobileNetV2 + Grad-CAM++"
          });
        }

        // 2. Safety Check: Blank/Low-Contrast Detection (Mocked via Brightness)
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d')!;
        canvas.width = 64;
        canvas.height = 64;
        ctx.drawImage(img, 0, 0, 64, 64);
        const imageData = ctx.getImageData(0, 0, 64, 64).data;
        let brightnessSum = 0;
        for (let i = 0; i < imageData.length; i += 4) {
          brightnessSum += (imageData[i] + imageData[i+1] + imageData[i+2]) / 3;
        }
        const avgBrightness = brightnessSum / (imageData.length / 4);
        
        if (avgBrightness < 5 || avgBrightness > 250) {
          return resolve({
            predictedClass: "None",
            confidence: 0,
            top3: [],
            heatmap: base64,
            status: 'rejected',
            rejectionReason: "Blank or extremely low-contrast image detected.",
            architecture: "MobileNetV2 + Grad-CAM++"
          });
        }

        // 3. Simulated Model Forward Pass
        const labels = LABEL_MAPPING.map(l => l.split(': ')[1] || l);
        const predictedIndex = Math.floor(Math.random() * labels.length);
        const confidence = 0.55 + Math.random() * 0.43; // 55% to 98%
        
        const top3: CnnProbability[] = [
          { label: labels[predictedIndex], score: confidence },
          { label: labels[(predictedIndex + 1) % labels.length], score: (1 - confidence) * 0.6 },
          { label: labels[(predictedIndex + 2) % labels.length], score: (1 - confidence) * 0.3 }
        ].sort((a, b) => b.score - a.score);

        // 4. Generate Enhanced Heatmap (Simulated Grad-CAM++)
        const heatmap = await generateGradCAMPlusPlus(img);

        // 5. Confidence Logic
        if (confidence < 0.6) {
          resolve({
            predictedClass: labels[predictedIndex],
            confidence,
            top3,
            heatmap,
            status: 'uncertain',
            rejectionReason: "Uncertain prediction – insufficient visual confidence",
            architecture: "MobileNetV2 + Grad-CAM++"
          });
        } else {
          resolve({
            predictedClass: labels[predictedIndex],
            confidence,
            top3,
            heatmap,
            status: 'success',
            architecture: "MobileNetV2 + Grad-CAM++"
          });
        }
      };
      img.src = base64;
    });
  }
};

/**
 * Creates a simulated Grad-CAM++ heatmap overlay using Canvas
 * Grad-CAM++ typically shows more fine-grained localized activations.
 */
async function generateGradCAMPlusPlus(img: HTMLImageElement): Promise<string> {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d')!;
  canvas.width = img.width;
  canvas.height = img.height;

  // Draw original image in grayscale for the backdrop
  ctx.filter = 'grayscale(1) contrast(1.2) brightness(0.8)';
  ctx.drawImage(img, 0, 0);
  ctx.filter = 'none';

  // Layer 1: Global Semantic Activation (Soft Blue/Green)
  ctx.globalAlpha = 0.4;
  ctx.globalCompositeOperation = 'screen';
  for (let i = 0; i < 3; i++) {
    drawBlob(ctx, canvas.width, canvas.height, 200, 'rgba(59, 130, 246, 0.4)');
  }

  // Layer 2: Targeted Pathological Activation (Grad-CAM++ Red/Yellow)
  ctx.globalAlpha = 0.8;
  ctx.globalCompositeOperation = 'overlay';
  for (let i = 0; i < 8; i++) {
    // Bias blobs toward center-ish for more realistic focus
    const x = canvas.width * (0.3 + Math.random() * 0.4);
    const y = canvas.height * (0.3 + Math.random() * 0.4);
    const radius = 30 + Math.random() * 80;
    
    const grad = ctx.createRadialGradient(x, y, 0, x, y, radius);
    grad.addColorStop(0, 'rgba(255, 0, 0, 0.9)');   // Peak (Red)
    grad.addColorStop(0.3, 'rgba(255, 127, 0, 0.7)'); // Orange
    grad.addColorStop(0.6, 'rgba(255, 255, 0, 0.4)'); // Yellow
    grad.addColorStop(1, 'rgba(0, 0, 255, 0)');      // Transparent

    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();
  }
  
  // Layer 3: High-Frequency "Feature" Highlights
  ctx.globalAlpha = 0.3;
  ctx.globalCompositeOperation = 'color-dodge';
  ctx.strokeStyle = 'white';
  ctx.lineWidth = 1;
  for (let i = 0; i < 15; i++) {
    const x = Math.random() * canvas.width;
    const y = Math.random() * canvas.height;
    ctx.beginPath();
    ctx.arc(x, y, 2, 0, Math.PI * 2);
    ctx.stroke();
  }

  return canvas.toDataURL('image/jpeg', 0.8);
}

function drawBlob(ctx: CanvasRenderingContext2D, w: number, h: number, maxRadius: number, color: string) {
  const x = Math.random() * w;
  const y = Math.random() * h;
  const radius = maxRadius * (0.5 + Math.random() * 0.5);
  
  const grad = ctx.createRadialGradient(x, y, 0, x, y, radius);
  grad.addColorStop(0, color);
  grad.addColorStop(1, 'rgba(0,0,0,0)');

  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.fill();
}
