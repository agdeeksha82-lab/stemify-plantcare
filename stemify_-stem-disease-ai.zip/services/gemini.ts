
import { GoogleGenAI, Type } from "@google/genai";
import { SYSTEM_PROMPT } from "../constants";
import { AnalysisResult } from "../types";

export const analyzeStemImage = async (base64Image: string): Promise<AnalysisResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: {
      parts: [
        { text: SYSTEM_PROMPT },
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: base64Image.split(',')[1] || base64Image
          }
        }
      ]
    },
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          diseaseName: { type: Type.STRING },
          scientificName: { type: Type.STRING },
          confidence: { type: Type.NUMBER },
          severity: { type: Type.STRING },
          explanation: { type: Type.STRING },
          affectedRegionDescription: { type: Type.STRING },
          detailedRecommendations: {
            type: Type.OBJECT,
            properties: {
              cultural: { type: Type.ARRAY, items: { type: Type.STRING } },
              biological: { type: Type.ARRAY, items: { type: Type.STRING } },
              chemical: { type: Type.ARRAY, items: { type: Type.STRING } },
              immediate: { type: Type.ARRAY, items: { type: Type.STRING } },
              prohibited: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ['cultural', 'biological', 'chemical', 'immediate', 'prohibited']
          },
          preventiveMeasures: { type: Type.ARRAY, items: { type: Type.STRING } },
          treatmentGuidelines: { type: Type.STRING },
          environmentalThresholds: {
            type: Type.OBJECT,
            properties: {
              idealTemp: { type: Type.STRING },
              idealHumidity: { type: Type.STRING },
              riskFactors: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ['idealTemp', 'idealHumidity', 'riskFactors']
          }
        },
        required: [
          'diseaseName', 'scientificName', 'confidence', 'severity', 
          'explanation', 'affectedRegionDescription', 'detailedRecommendations', 
          'preventiveMeasures', 'treatmentGuidelines', 'environmentalThresholds'
        ]
      }
    }
  });

  const text = response.text;
  if (!text) throw new Error("No analysis result received from the expert engine.");
  
  return JSON.parse(text) as AnalysisResult;
};
