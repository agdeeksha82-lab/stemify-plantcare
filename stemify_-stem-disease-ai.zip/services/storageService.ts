
import { HistoryItem, Specimen } from "../types";

export const Storage = {
  getRecords: (): HistoryItem[] => {
    const saved = localStorage.getItem('stemify_v2_history');
    return saved ? JSON.parse(saved) : [];
  },
  
  saveRecord: (record: HistoryItem) => {
    const history = Storage.getRecords();
    localStorage.setItem('stemify_v2_history', JSON.stringify([record, ...history]));
  },

  getSpecimens: (): Specimen[] => {
    const saved = localStorage.getItem('stemify_specimens');
    return saved ? JSON.parse(saved) : [];
  },

  saveSpecimen: (specimen: Specimen) => {
    const specimens = Storage.getSpecimens();
    const index = specimens.findIndex(s => s.id === specimen.id);
    if (index >= 0) {
      specimens[index] = specimen;
    } else {
      specimens.push(specimen);
    }
    localStorage.setItem('stemify_specimens', JSON.stringify(specimens));
  }
};
