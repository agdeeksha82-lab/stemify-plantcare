
import React, { useState } from 'react';
import { AppSettings } from '../types';
import { EMOJI_OPTIONS } from './SeasonalEngine';
import { Palette, Sparkles, Monitor, Shield, Eye, Rocket, Zap, Ghost, Trash2, ArrowUp, ArrowDown } from 'lucide-react';

interface SettingsViewProps {
  settings: AppSettings;
  onUpdate: (newSettings: AppSettings) => void;
}

const SettingsView: React.FC<SettingsViewProps> = ({ settings: initialSettings, onUpdate }) => {
  const [localSettings, setLocalSettings] = useState<AppSettings>(initialSettings);

  const handleUpdate = (updates: Partial<AppSettings>) => {
    const merged = { ...localSettings, ...updates };
    setLocalSettings(merged);
    onUpdate(merged);
  };

  const toggleParticle = (emoji: string) => {
    const current = localSettings.appearance.activeParticles || [];
    const next = current.includes(emoji) 
      ? current.filter(e => e !== emoji) 
      : [...current, emoji];
    handleUpdate({ appearance: { ...localSettings.appearance, activeParticles: next } });
  };

  const clearParticles = () => {
    handleUpdate({ appearance: { ...localSettings.appearance, activeParticles: [] } });
  };

  const THEME_OPTIONS = [
    { id: 'modern', label: 'Modern Lab', icon: Monitor, desc: 'Clean, professional interface' },
    { id: 'glass', label: 'Glassmorphism', icon: Palette, desc: 'Frosted glass effects' },
    { id: 'high-contrast', label: 'High Contrast', icon: Shield, desc: 'Maximum readability' },
    { id: 'matrix', label: 'Neural Matrix', icon: Zap, desc: 'Binary green pathology mode' },
    { id: 'cyberpunk', label: 'Cyberpunk', icon: Rocket, desc: 'Neon agriculture vibe' },
    { id: 'retro-crt', label: 'Retro Terminal', icon: Ghost, desc: 'Classic CRT aesthetic' }
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-10 pb-20 animate-in fade-in slide-in-from-bottom-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-4xl font-black tracking-tight text-slate-800">System Preferences</h2>
          <p className="text-slate-500 font-medium">Customize your neural diagnostic dashboard.</p>
        </div>
        <div className="bg-emerald-100 text-emerald-700 px-4 py-2 rounded-2xl font-black text-[10px] uppercase tracking-widest">
          CONFIG v2.5.4
        </div>
      </div>

      {/* Theme Selection */}
      <section className="bg-white rounded-[3rem] border border-slate-100 shadow-sm p-8">
        <h3 className="text-lg font-black mb-6 flex items-center gap-3">
          <Palette className="text-emerald-500" /> Interface Atmosphere
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {THEME_OPTIONS.map((theme) => (
            <button
              key={theme.id}
              onClick={() => handleUpdate({ appearance: { ...localSettings.appearance, theme: theme.id as any } })}
              className={`p-6 rounded-[2rem] border-2 text-left transition-all ${localSettings.appearance.theme === theme.id ? 'border-emerald-500 bg-emerald-50' : 'border-slate-50 bg-slate-50/50 hover:bg-slate-50'}`}
            >
              <div className="flex justify-between items-start mb-3">
                <theme.icon className={localSettings.appearance.theme === theme.id ? 'text-emerald-600' : 'text-slate-400'} size={24} />
                {localSettings.appearance.theme === theme.id && <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />}
              </div>
              <h4 className="font-bold text-slate-800">{theme.label}</h4>
              <p className="text-[10px] text-slate-500 font-medium mt-1 leading-tight">{theme.desc}</p>
            </button>
          ))}
        </div>
      </section>

      {/* Particle Selection Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <section className="lg:col-span-2 bg-white rounded-[3rem] border border-slate-100 shadow-sm p-8">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-black flex items-center gap-3">
              <Sparkles className="text-amber-500" /> Particle Micro-Manager
            </h3>
            <button 
              onClick={clearParticles}
              className="p-2 text-slate-400 hover:text-rose-500 transition-colors"
              title="Clear all"
            >
              <Trash2 size={18} />
            </button>
          </div>
          
          <p className="text-xs text-slate-400 mb-6 font-medium uppercase tracking-widest">Toggle small elements. Less is more.</p>
          
          <div className="space-y-8">
            {Object.entries(EMOJI_OPTIONS).map(([category, emojis]) => (
              <div key={category}>
                <h4 className="text-[10px] font-black text-slate-400 mb-3 uppercase tracking-[0.2em]">{category}</h4>
                <div className="flex flex-wrap gap-2">
                  {emojis.map(emoji => (
                    <button
                      key={emoji}
                      onClick={() => toggleParticle(emoji)}
                      className={`w-10 h-10 rounded-2xl flex items-center justify-center text-xl transition-all ${localSettings.appearance.activeParticles?.includes(emoji) ? 'bg-emerald-500 shadow-lg scale-110' : 'bg-slate-50 hover:bg-slate-100 text-slate-300'}`}
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 pt-8 border-t border-slate-50 grid grid-cols-2 gap-8">
            <div className="space-y-4">
              <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Quantity</span>
              <div className="flex gap-2">
                {[
                  { id: 'none', label: 'None' },
                  { id: 'low', label: 'Few' },
                  { id: 'medium', label: 'Some' },
                  { id: 'high', label: 'Many' }
                ].map(level => (
                  <button
                    key={level.id}
                    onClick={() => handleUpdate({ accessibility: { ...localSettings.accessibility, animationIntensity: level.id as any } })}
                    className={`flex-1 px-3 py-2 rounded-xl text-[9px] font-black uppercase transition-all ${localSettings.accessibility.animationIntensity === level.id ? 'bg-slate-900 text-white shadow-lg' : 'bg-slate-50 text-slate-400'}`}
                  >
                    {level.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Flow Direction</span>
              <div className="flex gap-2">
                <button
                  onClick={() => handleUpdate({ appearance: { ...localSettings.appearance, particleDirection: 'down' } })}
                  className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-[9px] font-black uppercase transition-all ${localSettings.appearance.particleDirection === 'down' ? 'bg-emerald-600 text-white shadow-lg' : 'bg-slate-50 text-slate-400'}`}
                >
                  <ArrowDown size={14} /> Down
                </button>
                <button
                  onClick={() => handleUpdate({ appearance: { ...localSettings.appearance, particleDirection: 'up' } })}
                  className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-[9px] font-black uppercase transition-all ${localSettings.appearance.particleDirection === 'up' ? 'bg-emerald-600 text-white shadow-lg' : 'bg-slate-50 text-slate-400'}`}
                >
                  <ArrowUp size={14} /> Up
                </button>
              </div>
            </div>
          </div>
        </section>

        <section className="bg-white rounded-[3rem] border border-slate-100 shadow-sm p-8 space-y-8">
          <h3 className="text-lg font-black mb-6 flex items-center gap-3">
            <Eye className="text-blue-500" /> Vision Filters
          </h3>
          
          <div className="space-y-4">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Global Overlay</label>
            <div className="grid grid-cols-1 gap-2">
              {[
                { id: 'none', label: 'Clear', icon: '🎥' },
                { id: 'grayscale', label: 'Diagnostic B&W', icon: '🎞️' },
                { id: 'sepia', label: 'Field Archive', icon: '📜' },
                { id: 'vibrant', label: 'Bio-Saturate', icon: '🌈' },
                { id: 'night-vision', label: 'Infrared', icon: '🌃' }
              ].map(filter => (
                <button
                  key={filter.id}
                  onClick={() => handleUpdate({ appearance: { ...localSettings.appearance, visualFilter: filter.id as any } })}
                  className={`w-full p-4 rounded-2xl border text-left flex items-center gap-4 transition-all ${localSettings.appearance.visualFilter === filter.id ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-slate-50 bg-slate-50/50 hover:bg-slate-50'}`}
                >
                  <span className="text-xl">{filter.icon}</span>
                  <span className="font-bold text-xs">{filter.label}</span>
                </button>
              ))}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default SettingsView;
