
import React, { useState } from 'react';
import { AnalysisResult, SeverityLevel, Specimen } from '../types';
import { Brain, Eye, AlertCircle, Layers, Camera, Download, Save, CheckCircle, Zap, Thermometer, Droplets, FlaskConical, Bug, Leaf, Fingerprint, Plus } from 'lucide-react';
import { generateInstitutionalReport } from '../services/pdfService';

interface AnalysisResultsProps {
  result: AnalysisResult;
  image: string;
  onReset: () => void;
  onSave?: (result: AnalysisResult, image: string) => void;
  specimens?: Specimen[];
  onLinkSpecimen?: (specimenId: string) => void;
  onCreateSpecimen?: (name: string, location: string, variety: string) => string;
}

const AnalysisResults: React.FC<AnalysisResultsProps> = ({ 
  result, image, onReset, onSave, specimens = [], onLinkSpecimen, onCreateSpecimen 
}) => {
  const [showHeatmap, setShowHeatmap] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [showTwinModal, setShowTwinModal] = useState(false);
  const [newTwinData, setNewTwinData] = useState({ name: '', location: '', variety: result.scientificName });

  const getSeverityColor = (level: string) => {
    switch (level.toLowerCase()) {
      case SeverityLevel.LOW: return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case SeverityLevel.MEDIUM: return 'bg-amber-100 text-amber-700 border-amber-200';
      case SeverityLevel.HIGH: return 'bg-rose-100 text-rose-700 border-rose-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const handleCreateAndLink = () => {
    if (onCreateSpecimen && onLinkSpecimen) {
      const id = onCreateSpecimen(newTwinData.name, newTwinData.location, newTwinData.variety);
      onLinkSpecimen(id);
      setIsSaved(true);
      setShowTwinModal(false);
    }
  };

  const recs = result.detailedRecommendations;
  const env = result.environmentalThresholds;

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-20">
      {/* Neural Visualizer Overlay */}
      <div className="relative group rounded-[3rem] overflow-hidden shadow-2xl bg-black aspect-video flex items-center justify-center">
        <img 
          src={showHeatmap ? result.cnnLayerInsights?.heatmap : image} 
          className="w-full h-full object-contain transition-all duration-500" 
          alt="Scan Source"
        />
        <div className="absolute top-6 left-6 flex flex-wrap gap-2">
          <button 
            onClick={() => setShowHeatmap(!showHeatmap)}
            className={`px-6 py-3 rounded-2xl font-black text-xs flex items-center gap-2 shadow-lg transition-all ${showHeatmap ? 'bg-amber-500 text-white' : 'bg-white/90 text-slate-900 backdrop-blur'}`}
          >
            {showHeatmap ? <Eye size={16} /> : <Layers size={16} />}
            {showHeatmap ? "HIDE GRAD-CAM" : "VIEW NEURAL ATTENTION"}
          </button>
          
          <button 
            onClick={() => generateInstitutionalReport(result, image)}
            className="px-6 py-3 rounded-2xl font-black text-xs flex items-center gap-2 shadow-lg transition-all bg-emerald-600 text-white hover:bg-emerald-700"
          >
            <Download size={16} /> PDF REPORT
          </button>

          <button 
            onClick={() => setShowTwinModal(true)}
            disabled={isSaved}
            className={`px-6 py-3 rounded-2xl font-black text-xs flex items-center gap-2 shadow-lg transition-all ${isSaved ? 'bg-slate-100 text-slate-400' : 'bg-blue-600 text-white hover:bg-blue-700'}`}
          >
            <Fingerprint size={16} /> {isSaved ? "TWIN UPDATED" : "LINK TO DIGITAL TWIN"}
          </button>
        </div>
      </div>

      {/* Twin Modal */}
      {showTwinModal && (
        <div className="fixed inset-0 z-[200] bg-slate-900/80 backdrop-blur-xl flex items-center justify-center p-6">
          <div className="bg-white rounded-[3rem] p-10 max-w-xl w-full shadow-2xl animate-in zoom-in-95 duration-300">
            <h3 className="text-3xl font-black text-slate-900 mb-2 flex items-center gap-3">
               <Fingerprint className="text-blue-600" /> Digital Twin Registry
            </h3>
            <p className="text-slate-500 font-medium mb-8">Track this specimen's recovery over time in the monitoring dashboard.</p>
            
            <div className="space-y-6">
              {specimens.length > 0 && (
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">LINK TO EXISTING SPECIMEN</p>
                  <div className="grid grid-cols-1 gap-2 max-h-40 overflow-y-auto pr-2 scrollbar-thin">
                    {specimens.map(s => (
                      <button 
                        key={s.id}
                        onClick={() => {onLinkSpecimen?.(s.id); setIsSaved(true); setShowTwinModal(false);}}
                        className="p-4 bg-slate-50 hover:bg-blue-50 border border-slate-100 hover:border-blue-200 rounded-2xl text-left transition-all group"
                      >
                        <div className="flex justify-between items-center">
                          <span className="font-bold text-slate-800">{s.name}</span>
                          <span className="text-[10px] font-black text-slate-400">{s.location}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="pt-6 border-t border-slate-100">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">OR REGISTER NEW TWIN</p>
                <div className="space-y-4">
                  <input 
                    type="text" placeholder="Specimen Identification Name (e.g. Stem-X22)"
                    className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 font-bold"
                    value={newTwinData.name}
                    onChange={e => setNewTwinData({...newTwinData, name: e.target.value})}
                  />
                  <input 
                    type="text" placeholder="Physical Location / GPS (e.g. Greenhouse 4, Row B)"
                    className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 font-bold"
                    value={newTwinData.location}
                    onChange={e => setNewTwinData({...newTwinData, location: e.target.value})}
                  />
                  <button 
                    disabled={!newTwinData.name || !newTwinData.location}
                    onClick={handleCreateAndLink}
                    className="w-full py-5 bg-blue-600 hover:bg-blue-700 text-white font-black rounded-2xl shadow-xl transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    <Plus size={20} /> INITIALIZE TWIN TRACKING
                  </button>
                </div>
              </div>
            </div>

            <button onClick={() => setShowTwinModal(false)} className="mt-8 text-slate-400 font-bold text-sm w-full text-center hover:text-slate-900 transition-colors">CANCEL</button>
          </div>
        </div>
      )}

      {/* Primary Diagnosis Header */}
      <div className="bg-white rounded-[3rem] p-8 shadow-sm border border-slate-100">
        <div className="flex flex-col lg:flex-row justify-between gap-8">
          <div className="space-y-4 max-w-2xl">
            <div className="flex items-center gap-3">
              <h2 className="text-5xl font-black text-slate-900 tracking-tighter leading-none">{result.diseaseName}</h2>
              <span className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border shrink-0 ${getSeverityColor(result.severity)}`}>
                {result.severity} SEVERITY
              </span>
            </div>
            <p className="text-emerald-600 font-bold italic text-lg leading-tight">{result.scientificName}</p>
            <div className="p-6 bg-slate-50 rounded-[2rem] border border-slate-100">
               <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                 <Brain size={14} className="text-emerald-500" /> Expert Neural Verdict
               </h3>
               <p className="text-slate-600 font-medium leading-relaxed">{result.explanation}</p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4 lg:w-80">
            <div className="bg-emerald-50 p-6 rounded-[2rem] border border-emerald-100 text-center">
              <p className="text-[10px] text-emerald-800 font-black uppercase tracking-widest mb-1">Global Confidence</p>
              <p className="text-3xl font-black text-emerald-600">{(result.confidence * 100).toFixed(0)}%</p>
            </div>
            <div className="bg-blue-50 p-6 rounded-[2rem] border border-blue-100 text-center">
              <p className="text-[10px] text-blue-800 font-black uppercase tracking-widest mb-1">CNN Saliency</p>
              <p className="text-3xl font-black text-blue-600">{(result.cnnLayerInsights?.confidence ? result.cnnLayerInsights.confidence * 100 : 0).toFixed(0)}%</p>
            </div>
          </div>
        </div>
      </div>

      {/* Environmental Targets */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
         <div className="bg-amber-50 rounded-[2.5rem] p-8 border border-amber-100">
            <div className="flex items-center gap-3 mb-4">
               <div className="p-3 bg-white rounded-2xl shadow-sm"><Thermometer className="text-amber-600" size={20} /></div>
               <span className="text-[10px] font-black text-amber-800 uppercase tracking-widest">Inhibition Temp</span>
            </div>
            <p className="text-3xl font-black text-amber-900">{env.idealTemp}</p>
         </div>
         <div className="bg-blue-50 rounded-[2.5rem] p-8 border border-blue-100">
            <div className="flex items-center gap-3 mb-4">
               <div className="p-3 bg-white rounded-2xl shadow-sm"><Droplets className="text-blue-600" size={20} /></div>
               <span className="text-[10px] font-black text-blue-800 uppercase tracking-widest">Humidity Target</span>
            </div>
            <p className="text-3xl font-black text-blue-900">{env.idealHumidity}</p>
         </div>
         <div className="bg-slate-900 rounded-[2.5rem] p-8 border border-slate-800">
            <div className="flex items-center gap-3 mb-4">
               <div className="p-3 bg-slate-800 rounded-2xl shadow-sm"><AlertCircle className="text-rose-500" size={20} /></div>
               <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Risk Factors</span>
            </div>
            <div className="flex flex-wrap gap-2">
               {env.riskFactors.map((f, i) => (
                 <span key={i} className="text-[9px] font-black bg-slate-800 text-slate-300 px-3 py-1 rounded-full uppercase">{f}</span>
               ))}
            </div>
         </div>
      </div>

      {/* Recommendation Blocks */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="bg-rose-50 rounded-[3rem] p-8 border border-rose-100">
            <h3 className="text-rose-900 font-black text-2xl mb-6 flex items-center gap-3">
              <Zap size={24} /> PRIORITY 1 INTERVENTION
            </h3>
            <div className="space-y-3">
              {recs.immediate.map((item, i) => (
                <div key={i} className="flex gap-4 p-4 bg-white/60 backdrop-blur rounded-2xl border border-rose-200 text-rose-900 font-bold text-sm">
                  <div className="w-5 h-5 bg-rose-500 rounded-full flex items-center justify-center text-[10px] text-white shrink-0">!</div>
                  {item}
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-6">
           <div className="bg-white rounded-[2.5rem] p-8 border border-slate-100 shadow-sm">
              <h3 className="text-emerald-900 font-black text-lg mb-6 flex items-center gap-3">
                 <Leaf size={18} className="text-emerald-600" /> Cultural Control
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {recs.cultural.map((item, i) => (
                  <div key={i} className="p-4 bg-emerald-50/50 border border-emerald-100 rounded-2xl text-[11px] font-bold text-emerald-800">
                    • {item}
                  </div>
                ))}
              </div>
           </div>
        </div>
      </div>

      {/* Global Reset */}
      <div className="flex flex-col items-center pt-12 pb-20 gap-4">
        <button 
          onClick={onReset}
          className="bg-emerald-600 hover:bg-emerald-700 text-white font-black py-5 px-16 rounded-[2.5rem] shadow-2xl transition-all active:scale-95 flex items-center gap-3"
        >
          <Camera size={20} /> NEW SCAN SEQUENCE
        </button>
      </div>
    </div>
  );
};

export default AnalysisResults;
