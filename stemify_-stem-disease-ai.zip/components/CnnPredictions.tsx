
import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { MOCK_TRAINING_DATA, MODEL_ARCHITECTURE_INFO, CONFUSION_MATRIX, TRAINING_CODE_SNIPPET } from '../constants';

const CnnPredictions: React.FC = () => {
  return (
    <div className="space-y-12 pb-20 animate-in fade-in slide-in-from-bottom-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-5">
        <div>
          <h2 className="text-5xl font-black tracking-tighter text-slate-800">CNN Algorithm</h2>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">ML Lifecycle: Steps 7–12 (Architecture to Reproducibility)</p>
        </div>
        <div className="bg-white px-8 py-4 rounded-[2rem] shadow-md border border-slate-100">
           <span className="text-2xl font-black text-emerald-600">94.2%</span>
           <span className="text-[9px] font-black uppercase text-slate-400 ml-3">Final Accuracy</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        <div className="bg-white p-10 rounded-[3.5rem] shadow-sm border border-slate-100 space-y-8">
          <h3 className="text-xl font-black flex items-center gap-3">
             <span className="w-2 h-6 bg-emerald-500 rounded-full"></span>
             Architecture (Step 7)
          </h3>
          <div className="space-y-5">
             <div className="p-6 bg-slate-50 rounded-[2rem] border border-emerald-100 group overflow-hidden relative">
               <p className="text-emerald-600 text-[9px] font-black uppercase tracking-widest mb-1">Backbone</p>
               <h4 className="text-xl font-black tracking-tight text-slate-800">{MODEL_ARCHITECTURE_INFO.backbone}</h4>
             </div>
             <div className="space-y-2">
                {MODEL_ARCHITECTURE_INFO.customHead.map((h, i) => (
                  <div key={i} className="flex items-center gap-4 p-4 bg-white rounded-2xl border border-slate-100 font-bold text-slate-600 text-xs">
                    <span className="w-5 h-5 rounded-lg bg-slate-50 text-slate-400 flex items-center justify-center text-[9px]">{i+1}</span>
                    {h}
                  </div>
                ))}
             </div>
          </div>
        </div>

        <div className="space-y-6">
           <div className="bg-white p-10 rounded-[3.5rem] shadow-md border border-slate-100 relative overflow-hidden group">
              <h3 className="text-xl font-black text-slate-800 mb-6 uppercase tracking-tight">Source Implementation</h3>
              <div className="bg-slate-900 p-6 rounded-[1.5rem] border border-slate-800 font-mono text-[9px] text-emerald-400 leading-relaxed overflow-x-auto h-[280px]">
                <pre>{TRAINING_CODE_SNIPPET.trim()}</pre>
              </div>
              <div className="mt-6 flex justify-between items-center text-[10px] font-black uppercase tracking-widest text-slate-400">
                 <span>Adam (lr=1e-4)</span>
                 <span>Cross-Entropy Loss</span>
              </div>
           </div>
        </div>
      </div>

      <div className="bg-white p-10 rounded-[3.5rem] shadow-sm border border-slate-100">
        <h3 className="text-xl font-black mb-8">Convergence Path (Step 9)</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={MOCK_TRAINING_DATA}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="epoch" stroke="#94a3b8" fontSize={9} axisLine={false} tickLine={false} />
              <YAxis domain={[0.5, 1]} stroke="#94a3b8" fontSize={9} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 5px 15px rgba(0,0,0,0.05)' }} />
              <Area type="monotone" dataKey="accuracy" stroke="#10b981" fill="#10b981" fillOpacity={0.05} strokeWidth={3} />
              <Area type="monotone" dataKey="val_accuracy" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.02} strokeWidth={3} strokeDasharray="5 5" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-slate-50 p-10 rounded-[3.5rem] shadow-sm border border-slate-200/50">
        <h3 className="text-xl font-black text-slate-800 mb-10">Evaluation Matrix (Steps 10 & 11)</h3>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2 overflow-x-auto">
             <div className="min-w-[450px] grid grid-cols-6 gap-2">
                <div className="col-span-1"></div>
                {CONFUSION_MATRIX.labels.map(l => (
                  <div key={l} className="text-[8px] font-black text-slate-400 text-center uppercase">{l}</div>
                ))}
                {CONFUSION_MATRIX.labels.map((rowLabel, i) => (
                  <React.Fragment key={i}>
                    <div className="text-[8px] font-black text-slate-400 flex items-center justify-end uppercase pr-3">{rowLabel}</div>
                    {CONFUSION_MATRIX.data[i].map((val, j) => (
                      <div key={`${i}-${j}`} className={`aspect-square rounded-xl flex items-center justify-center text-[11px] font-black ${i === j ? 'bg-emerald-500 text-white shadow-sm' : 'bg-white border border-slate-100 text-slate-300'}`}>
                        {val}%
                      </div>
                    ))}
                  </React.Fragment>
                ))}
             </div>
          </div>
          <div className="space-y-4">
             <div className="p-6 bg-white rounded-3xl border border-slate-200">
               <p className="text-emerald-600 text-[8px] font-black uppercase mb-2">Analysis</p>
               <p className="text-[11px] text-slate-500 leading-relaxed font-medium">Strong diagonal dominance confirms efficacy of MobileNetV2 feature space extraction.</p>
             </div>
             <div className="flex gap-4">
                <div className="flex-1 p-5 bg-white rounded-3xl border border-slate-200 text-center">
                   <p className="text-[8px] font-black text-slate-400 uppercase">F1-Score</p>
                   <p className="text-xl font-black text-slate-800">0.91</p>
                </div>
                <div className="flex-1 p-5 bg-white rounded-3xl border border-slate-200 text-center">
                   <p className="text-[8px] font-black text-slate-400 uppercase">Precision</p>
                   <p className="text-xl font-black text-slate-800">0.93</p>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CnnPredictions;
