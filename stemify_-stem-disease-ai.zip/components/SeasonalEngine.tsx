
import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { SeasonalMode } from '../types';

export const EMOJI_OPTIONS = {
  Nature: ['🌸', '🌱', '🌼', '🦋', '🍂', '🍁', '🍀', '🌿', '🍃'],
  Agriculture: ['🌾', '🌽', '🍅', '🍎', '🚜', '🧑‍🌾', '🥦', '🍓', '🥕'],
  Weather: ['❄️', '⛄', '☀️', '☁️', '⚡', '💧', '🌈', '🌪️'],
  Science: ['🧬', '🔬', '🧪', '🧠', '💻', '📡', '🔋', '🔬']
};

const DEFAULT_SEASON_EMOJIS: Record<string, string[]> = {
  Spring: ['🌸', '🌱', '🌼', '🦋', '🍃'],
  Summer: ['☀️', '🌻', '🐝', '🍉', '🍦'],
  Autumn: ['🍂', '🍁', '🍄', '🍎', '🌰'],
  Winter: ['❄️', '⛄', '🌲', '🧤', '🏂']
};

interface ParticleProps {
  emoji: string;
  delay: number;
  duration: number;
  startX: string;
  xDrift: number;
  rotation: number;
  size: number;
  direction: 'up' | 'down';
}

const Particle: React.FC<ParticleProps> = ({ emoji, delay, duration, startX, xDrift, rotation, size, direction }) => (
  <motion.div
    initial={{ 
      x: startX, 
      y: direction === 'down' ? '-15vh' : '115vh', 
      rotate: 0,
      opacity: 0,
      scale: size * 0.5
    }}
    animate={{ 
      y: direction === 'down' ? '115vh' : '-15vh',
      rotate: rotation,
      x: `calc(${startX} + ${xDrift}px)`,
      opacity: [0, 0.4, 0.4, 0], // Reduced opacity for background subtlety
      scale: size
    }}
    transition={{ 
      duration, 
      repeat: Infinity, 
      ease: "linear",
      delay
    }}
    style={{ 
      fontSize: `${size}rem`,
      left: 0,
      top: 0,
      position: 'fixed'
    }}
    className="fixed select-none pointer-events-none z-0 will-change-transform"
  >
    {emoji}
  </motion.div>
);

export const SeasonalParticles: React.FC<{ 
  mode: SeasonalMode; 
  intensity: 'high' | 'medium' | 'low' | 'none';
  customParticles?: string[];
  direction?: 'up' | 'down';
}> = ({ mode, intensity, customParticles, direction = 'down' }) => {
  const particleCount = useMemo(() => {
    switch (intensity) {
      case 'high': return 75; 
      case 'medium': return 45; 
      case 'low': return 20;
      case 'none': return 0;
      default: return 45;
    }
  }, [intensity]);

  const particles = useMemo(() => {
    let emojis = customParticles && customParticles.length > 0 
      ? customParticles 
      : (DEFAULT_SEASON_EMOJIS[mode] || EMOJI_OPTIONS.Nature);

    if (particleCount === 0 || emojis.length === 0) return [];

    return Array.from({ length: particleCount }).map((_, i) => ({
      id: i,
      emoji: emojis[Math.floor(Math.random() * emojis.length)],
      delay: Math.random() * 25,
      duration: 18 + Math.random() * 20, 
      startX: (Math.random() * 100) + 'vw', 
      xDrift: (Math.random() - 0.5) * 400,
      rotation: (Math.random() - 0.5) * 1080,
      size: 0.4 + Math.random() * 0.6 // Kept small as requested earlier
    }));
  }, [mode, particleCount, customParticles]);

  if (intensity === 'none' || particles.length === 0) return null;

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {particles.map((p) => (
        <Particle key={p.id} {...p} direction={direction} />
      ))}
    </div>
  );
};

export const SeasonalEngine = SeasonalParticles;
