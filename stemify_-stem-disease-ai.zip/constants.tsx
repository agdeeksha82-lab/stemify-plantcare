
import React from 'react';

export const SYSTEM_PROMPT = `
You are a world-class senior plant pathologist and agricultural consultant. 
Analyze the provided image specifically targeting the plant stem.
Generate an exhaustive diagnostic report in JSON format.

The recommendations MUST be split into:
1. Cultural Controls: Pruning, spacing, irrigation adjustments.
2. Biological Controls: Beneficial microbes, natural predators, or bio-fungicides.
3. Chemical Controls: Specific active ingredients (e.g., Mancozeb, Copper oxychloride) with safety precautions.
4. Immediate Actions: Priority 1 steps to take within 24 hours.
5. Prohibited Actions: Things that will worsen the condition.

Environmental Thresholds:
Provide ideal temperature and humidity ranges to inhibit this specific pathogen, and list environmental risk factors (e.g., stagnant water).

Response MUST be valid JSON only with the following keys:
diseaseName, scientificName, confidence (0-1), severity (low/medium/high), explanation, affectedRegionDescription, 
detailedRecommendations (cultural, biological, chemical, immediate, prohibited), 
preventiveMeasures, treatmentGuidelines, 
environmentalThresholds (idealTemp, idealHumidity, riskFactors).
`;

export const PROJECT_EXPLANATION = {
  abstract: "STEMIFY is an advanced AI system for intelligent plant stem disease identification and management using deep learning. It focuses on early-stage detection, severity assessment, and actionable recommendations for sustainable agriculture."
};

export const PLANT_SPECIES_CATALOG = [
  { name: "Rice", diseases: ["Stem Rot"] },
  { name: "Wheat", diseases: ["Stem Rust"] },
  { name: "Dragon Fruit", diseases: ["Stem Canker"] },
  { name: "Tomato", diseases: ["Wilt"] },
  { name: "Cotton", diseases: ["Blight"] }
];

export const MOCK_TRAINING_DATA = [
  { epoch: 1, accuracy: 0.65, val_accuracy: 0.60 },
  { epoch: 2, accuracy: 0.72, val_accuracy: 0.68 },
  { epoch: 3, accuracy: 0.78, val_accuracy: 0.75 },
  { epoch: 4, accuracy: 0.85, val_accuracy: 0.81 },
  { epoch: 5, accuracy: 0.91, val_accuracy: 0.88 },
  { epoch: 6, accuracy: 0.93, val_accuracy: 0.91 },
  { epoch: 7, accuracy: 0.95, val_accuracy: 0.92 },
  { epoch: 8, accuracy: 0.96, val_accuracy: 0.93 },
  { epoch: 9, accuracy: 0.97, val_accuracy: 0.94 },
  { epoch: 10, accuracy: 0.98, val_accuracy: 0.94 },
];

export const MODEL_ARCHITECTURE_INFO = {
  backbone: "ResNet50 / MobileNetV2 (Transfer Learning)",
  customHead: [
    "GlobalAveragePooling2D",
    "Dense (1024, Activation: ReLU)",
    "Batch Normalization",
    "Dropout (0.3) [Regularization]",
    "Dense (512, Activation: ReLU)",
    "Softmax (Number of Classes)"
  ]
};

export const CONFUSION_MATRIX = {
  labels: ["Healthy", "Rust", "Canker", "Wilt", "Blight"],
  data: [
    [98, 1, 0, 1, 0],
    [2, 94, 2, 1, 1],
    [0, 3, 91, 4, 2],
    [1, 1, 3, 95, 0],
    [1, 2, 2, 1, 94]
  ]
};

export const TRAINING_CODE_SNIPPET = `
def build_robust_cnn(num_classes, weights='imagenet'):
    base_model = MobileNetV2(weights=weights, include_top=False, input_shape=(224, 224, 3))
    base_model.trainable = False
    
    x = base_model.output
    x = GlobalAveragePooling2D()(x)
    x = Dense(1024, activation='relu')(x)
    x = BatchNormalization()(x)
    x = Dropout(0.3)(x)
    outputs = Dense(num_classes, activation='softmax')(x)
    
    model = Model(inputs=base_model.input, outputs=outputs)
    model.compile(optimizer=Adam(lr=1e-4), loss='categorical_crossentropy', metrics=['accuracy'])
    return model
`;

export const KAGGLE_DATASETS = [
  { name: "Stem Disease Identification Base", url: "kaggle.com/datasets/stemify/base-v2", loading: "kagglehub.dataset_download('stemify/base-v2')", count: 4200, label: 0 },
  { name: "Cereal Stem Rust Patterns", url: "kaggle.com/datasets/agri-ai/wheat-stem-rust", loading: "kagglehub.dataset_download('agri-ai/wheat-stem-rust')", count: 1850, label: 1 },
  { name: "Tropical Fruit Stem Canker", url: "kaggle.com/datasets/vkit/dragon-fruit-canker", loading: "kagglehub.dataset_download('vkit/dragon-fruit-canker')", count: 1200, label: 2 },
  { name: "Solanaceous Wilt Collection", url: "kaggle.com/datasets/botany-labs/tomato-wilt", loading: "kagglehub.dataset_download('botany-labs/tomato-wilt')", count: 980, label: 3 },
  { name: "Cotton Blight Stem Features", url: "kaggle.com/datasets/agri-tech/cotton-blight", loading: "kagglehub.dataset_download('agri-tech/cotton-blight')", count: 720, label: 4 },
  { name: "Healthy Plant Reference", url: "kaggle.com/datasets/stemify/healthy-baseline", loading: "kagglehub.dataset_download('stemify/healthy-baseline')", count: 600, label: 5 }
];

export const LABEL_MAPPING = [
  "0: Baseline Healthy",
  "1: Puccinia graminis (Rust)",
  "2: Neoscytalidium (Canker)",
  "3: Fusarium oxysporum (Wilt)",
  "4: Xanthomonas (Blight)",
  "5: Environmental Scorch"
];

export const THEMES = {
  modern: { label: 'Modern Lab' },
  glass: { label: 'Glassmorphism' },
  'high-contrast': { label: 'High Contrast' },
  matrix: { label: 'Neural Matrix' },
  cyberpunk: { label: 'Cyberpunk' },
  'retro-crt': { label: 'Retro Terminal' }
};

export const SEASONS: Record<string, { label: string, icon: string }> = {
  Spring: { label: 'Spring', icon: '🌸' },
  Summer: { label: 'Summer', icon: '☀️' },
  Autumn: { label: 'Autumn', icon: '🍂' },
  Winter: { label: 'Winter', icon: '❄️' }
};
