
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, Variants } from 'framer-motion';
import { 
  Camera, History, Activity, Shield, 
  MessageSquare, Settings, Zap, 
  Globe, Cpu, AlertTriangle, Fingerprint
} from 'lucide-react';

import Header from './components/Header';
import ImageUploader from './components/ImageUploader';
import AnalysisResults from './components/AnalysisResults';
import IoTStats from './components/IoTStats';
import ChatView from './components/ChatView';
import CnnPredictions from './components/CnnPredictions';
import SettingsView from './components/SettingsView';
import { SpecimenMonitor } from './components/SpecimenMonitor';
import { SeasonalEngine } from './components/SeasonalEngine';

import { analyzeStemImage } from './services/gemini';
import { preprocessStemImage } from './services/imageProcessor';
import { CnnService } from './services/cnnService';
import { DatabaseService } from './services/databaseService';
import { Storage } from './services/storageService';
import { 
  AnalysisResult, HistoryItem, IoTData, 
  SeasonalMode, AppSettings, Specimen, SeverityLevel
} from './types';

const DEFAULT_SETTINGS: AppSettings = {
  branding: {
    orgName: "STEMIFY Institutional",
    contact: { website: "stemify.agri.edu" },
    footerText: "Institutional Protocol v2.5 - Automated Pathological Validation",
    primaryColor: "#10b981",
    secondaryColor: "#3b82f6"
  },
  appearance: {
    theme: 'modern',
    season: 'Spring',
    activeParticles: ['🍃', '🌿', '🌱'],
    visualFilter: 'none',
    particleDirection: 'down'
  },
  accessibility: {
    animationIntensity: 'high',
    neuralGlow: false,
    highPrecisionCursors: false
  }
};

const calculateHealthScore = (severity: SeverityLevel): number => {
  switch (severity) {
    case SeverityLevel.LOW: return 65; // Even low rust is a 35% health reduction
    case SeverityLevel.MEDIUM: return 35;
    case SeverityLevel.HIGH: return 12;
    default: return 100;
  }
};

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'home' | 'scan' | 'specimens' | 'cnn' | 'advisor' | 'settings'>('home');
  const [currentImage, setCurrentImage] = useState<string | null>(null);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadingStatus, setLoadingStatus] = useState<string>('');
  const [history, setHistory] = useState<HistoryItem[]>(Storage.getRecords());
  const [specimens, setSpecimens] = useState<Specimen[]>(Storage.getSpecimens());
  const [iotData, setIotData] = useState<IoTData>({ temperature: 24, humidity: 65, soilMoisture: 42, lastUpdated: Date.now() });
  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('stemify_settings');
    const parsed = saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
    return parsed;
  });
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncError, setSyncError] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem('stemify_v2_history', JSON.stringify(history));
  }, [history]);

  useEffect(() => {
    localStorage.setItem('stemify_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    const interval = setInterval(() => {
      setIotData(p => ({
        ...p,
        temperature: +(p.temperature + (Math.random() - 0.5)).toFixed(1),
        humidity: +(p.humidity + (Math.random() - 0.5) * 2).toFixed(1),
        lastUpdated: Date.now()
      }));
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleScan = async (base64: string) => {
    setLoading(true);
    setSyncError(null);
    try {
      setLoadingStatus('Preprocessing (CLAHE Standardization)...');
      const processed = await preprocessStemImage(base64);
      
      setLoadingStatus('Running Local CNN Inference (MobileNetV2)...');
      const cnnResult = await CnnService.runInference(processed);
      
      if (cnnResult.status === 'rejected') {
        throw new Error(cnnResult.rejectionReason || "Inference Rejected");
      }

      setLoadingStatus('Consulting Expert Neural Pathologist...');
      const res = await analyzeStemImage(processed);
      
      const finalResult: AnalysisResult = {
        ...res,
        cnnLayerInsights: cnnResult
      };

      setResult(finalResult);
      setCurrentImage(processed);
    } catch (e: any) {
      console.error(e);
      setSyncError(e.message || "An unexpected error occurred during neural analysis.");
    } finally {
      setLoading(false);
      setLoadingStatus('');
    }
  };

  const handleSaveResult = async (res: AnalysisResult, img: string, specimenId?: string) => {
    setIsSyncing(true);
    const newHistory: HistoryItem = {
      id: crypto.randomUUID(),
      timestamp: Date.now(),
      image: img,
      result: res,
      syncStatus: 'pending',
      specimenId
    };
    
    setHistory(prev => [newHistory, ...prev]);

    if (specimenId) {
      const targetSpecimen = specimens.find(s => s.id === specimenId);
      if (targetSpecimen) {
        const updatedSpecimen: Specimen = {
          ...targetSpecimen,
          healthHistory: [...targetSpecimen.healthHistory, { 
            timestamp: Date.now(), 
            score: calculateHealthScore(res.severity), 
            historyId: newHistory.id 
          }]
        };
        Storage.saveSpecimen(updatedSpecimen);
        setSpecimens(Storage.getSpecimens());
      }
    }

    const syncSuccess = await DatabaseService.syncDetection(newHistory);
    if (syncSuccess) {
      setHistory(prev => prev.map(item => 
        item.id === newHistory.id ? { ...item, syncStatus: 'synced' as const } : item
      ));
    }
    setIsSyncing(false);
  };

  const handleCreateSpecimen = (name: string, location: string, variety: string, initialResult?: AnalysisResult) => {
    const newId = crypto.randomUUID();
    const newSpecimen: Specimen = {
      id: newId,
      name,
      location,
      variety,
      createdAt: Date.now(),
      healthHistory: initialResult ? [{
        timestamp: Date.now(),
        score: calculateHealthScore(initialResult.severity),
        historyId: 'initial'
      }] : []
    };
    Storage.saveSpecimen(newSpecimen);
    setSpecimens(Storage.getSpecimens());
    return newId;
  };

  const themeClasses = {
    modern: 'bg-slate-50',
    glass: 'bg-gradient-to-br from-indigo-50 via-white to-emerald-50 backdrop-blur-3xl',
    'high-contrast': 'bg-white font-mono',
    matrix: 'bg-black text-emerald-500 font-mono',
    cyberpunk: 'bg-[#0f0524] text-pink-500 font-bold',
    'retro-crt': 'bg-[#1a1c1a] text-[#33ff33] font-mono'
  };

  return (
    <div className={`min-h-screen flex flex-col relative transition-all duration-700 ${themeClasses[settings.appearance.theme]}`}>
      <SeasonalEngine 
        mode={settings.appearance.season} 
        intensity={settings.accessibility.animationIntensity} 
        customParticles={settings.appearance.activeParticles}
        direction={settings.appearance.particleDirection}
      />

      <nav className={`fixed left-0 top-0 bottom-0 w-24 z-50 flex flex-col items-center py-8 gap-8 transition-all ${settings.appearance.theme === 'matrix' || settings.appearance.theme === 'retro-crt' ? 'bg-black border-r border-emerald-900' : 'glass-dark'}`}>
        <div className="w-12 h-12 rounded-2xl flex items-center justify-center font-black shadow-lg text-xl bg-emerald-500 text-white">Σ</div>
        <div className="flex-1 flex flex-col gap-5">
          {[
            { id: 'home', icon: Globe, label: 'Home' },
            { id: 'scan', icon: Camera, label: 'Scan' },
            { id: 'specimens', icon: Fingerprint, label: 'Twins' },
            { id: 'cnn', icon: Cpu, label: 'Model' },
            { id: 'advisor', icon: MessageSquare, label: 'Advisor' }
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`p-4 rounded-2xl transition-all ${activeTab === item.id ? 'bg-emerald-500 text-white shadow-xl scale-110' : 'text-slate-400 hover:text-white hover:bg-white/10'}`}
            >
              <item.icon size={22} />
            </button>
          ))}
        </div>
        <button onClick={() => setActiveTab('settings')} className={`p-4 transition-all ${activeTab === 'settings' ? 'bg-emerald-500 text-white rounded-2xl scale-110' : 'text-slate-400 hover:text-white hover:bg-white/10'}`}>
          <Settings size={24} />
        </button>
      </nav>

      <main className="flex-1 ml-24 p-8 relative z-10">
        <AnimatePresence mode="wait">
          {activeTab === 'home' && (
            <motion.div key="home" variants={pageVariants} initial="initial" animate="animate" exit="exit" className="max-w-7xl mx-auto space-y-12">
              <section className="flex flex-col lg:flex-row gap-12 items-center pt-12">
                <div className="flex-1 space-y-8 text-center lg:text-left">
                  <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-100 text-emerald-700 rounded-full font-bold text-sm tracking-widest">
                    <Shield size={16} /> INSTITUTIONAL ACCESS GRANTED
                  </div>
                  <h1 className="text-7xl font-[800] leading-[1.1] tracking-tighter text-slate-900">
                    AI Pathologist for <span className="text-emerald-600">Smart Stem</span> Engineering
                  </h1>
                  <p className="text-xl max-w-2xl font-medium leading-relaxed text-slate-500">
                    Deploying Digital Twin temporal tracking and deep learning protocols for real-time diagnostics and integrated recovery management.
                  </p>
                  <div className="flex flex-wrap gap-4 justify-center lg:justify-start">
                    <button onClick={() => setActiveTab('scan')} className="px-10 py-5 rounded-3xl font-bold shadow-2xl transition-all hover:-translate-y-1 bg-emerald-600 text-white flex items-center gap-3">
                      <Camera /> ENTER DIAGNOSTIC LAB
                    </button>
                    <button onClick={() => setActiveTab('specimens')} className="bg-slate-900 text-white px-10 py-5 rounded-3xl font-bold flex items-center gap-3 hover:bg-black transition-all">
                      <Activity /> MONITOR DIGITAL TWINS
                    </button>
                  </div>
                </div>
                <div className="flex-1 relative">
                  <img src="https://images.unsplash.com/photo-1591857177580-dc82b9ac4e1e?auto=format&fit=crop&q=80&w=800" className="rounded-[3rem] shadow-2xl w-full h-[500px] object-cover" />
                </div>
              </section>
              <IoTStats data={iotData} />
            </motion.div>
          )}

          {activeTab === 'scan' && (
            <motion.div key="scan" variants={pageVariants} initial="initial" animate="animate" exit="exit" className="max-w-4xl mx-auto space-y-8">
              {!result ? (
                <div className="space-y-8">
                  <div className="text-center">
                    <h2 className="text-4xl font-extrabold text-slate-900">Diagnostic Laboratory</h2>
                    <p className="mt-2 font-medium text-slate-500">Neural feature extraction protocol v2.1</p>
                  </div>
                  <ImageUploader onImageSelect={handleScan} isLoading={loading} />
                </div>
              ) : (
                <AnalysisResults 
                  result={result} 
                  image={currentImage || ''} 
                  onReset={() => {setResult(null); setCurrentImage(null);}} 
                  onSave={(res, img) => handleSaveResult(res, img)}
                  specimens={specimens}
                  onLinkSpecimen={(id) => handleSaveResult(result, currentImage!, id)}
                  onCreateSpecimen={(n, l, v) => handleCreateSpecimen(n, l, v, result)}
                />
              )}
            </motion.div>
          )}

          {activeTab === 'specimens' && (
            <motion.div key="specimens" variants={pageVariants} initial="initial" animate="animate" exit="exit" className="max-w-7xl mx-auto">
              <SpecimenMonitor specimens={specimens} history={history} />
            </motion.div>
          )}

          {activeTab === 'cnn' && (
            <motion.div key="cnn" variants={pageVariants} initial="initial" animate="animate" exit="exit" className="max-w-7xl mx-auto">
              <CnnPredictions />
            </motion.div>
          )}

          {activeTab === 'advisor' && (
            <motion.div key="advisor" variants={pageVariants} initial="initial" animate="animate" exit="exit">
              <ChatView />
            </motion.div>
          )}

          {activeTab === 'settings' && (
            <motion.div key="settings" variants={pageVariants} initial="initial" animate="animate" exit="exit">
              <SettingsView settings={settings} onUpdate={setSettings} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
};

const pageVariants: Variants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -20 }
};

export default App;
